package com.example.demo.Exceptions;

public class ISBNAlreadyExistsException extends RuntimeException {

	public  ISBNAlreadyExistsException(String message) {
		super(message);
	}
	
	
}
